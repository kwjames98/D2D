[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/PFJ2jOUW)
# 1. Hello PyTorch, Hello CNN!
Programming Assignment "1. Hello PyTorch, Hello CNN!" for 2023 Summer DeepIntoDeep

**Due Date 2023.07.23**

'D2D' 폴더 전체를 본인의 구글 드라이브에 업로드 한 후에, "1. Hello PyTorch, Hello CNN!.ipynb"를 Colab으로 열어주세요.

Colab 첫번째 Text block의
```FOLDERNAME = None```
을 본인 경로에 맞게 수정하는 것을 잊지 마세요!
